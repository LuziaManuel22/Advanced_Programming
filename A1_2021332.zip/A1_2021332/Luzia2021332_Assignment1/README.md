# Advanced Programming : Assignment 1

# Library Management System

Welcome to the Library Management System, a Java-based application for managing books and members in a library. This project implements various functionalities using Object-Oriented Programming (OOP) principles to provide a user-friendly interface for both librarians and members.

## Topics for this assignment : Classes, Objects, Encapsulation & Class Relationships


## Functionalities

- **Add Book**: Librarians can add new books to the library, including details like book ID, title, author, and total copies.


- **Remove Book**: Librarians can remove books from the library by providing the book ID.


- **Register Member**: Librarians can register new members with their details such as name, age, and phone number.


- **Remove Member**: Librarians can remove members from the library using the member's unique identifier.


- **Enter as a Member**: Members can log in using their name and phone number if they are already registered.


- **Issue Book**: Members can borrow books from the library, provided their penalty amount is zero and there are available copies of the book.


- **Return Book**: Members can return borrowed books. The system calculates fines if the book is returned after the due date.


- **List Books**: Display a list of all available books in the library.


- **List Members**: Display a list of all registered members of the library.


- **Calculate Fine**: Calculate and display the fine amount for a book returned after the due date.


- **Exit**: Terminate the application.


## Getting Started

1- Clone this repository to your computer.

2- Open the project using IntelliJ IDEA or your preferred IDE.

3- Ensure Maven is installed and configured:

Check Maven installation: 
Run **mvn -version** in your terminal and verify it displays the Maven version.

4- Import the project as a Maven project within your IDE.

5- Run the application by right-clicking on the Main.java class and selecting "Run."

6- **If you want to run the project without an IDE or directly with the JAR file**

- Navigate to the directory containing the JAR file in the terminal:

run : **cd path_to_directory_with_the_jar_file**

-Execute the following command to run the JAR file:

run: **java -jar Luzia2021332_Assignment1-1.0-SNAPSHOT.jar**


Please adjust IDE settings to set Main.java as the program's entry point. These steps should apply to most Maven-compatible IDEs.

## Created by: Luzia Xavier Manuel



