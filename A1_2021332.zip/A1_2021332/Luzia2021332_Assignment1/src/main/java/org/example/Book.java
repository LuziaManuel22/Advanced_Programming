package org.example;
import java.util.Date;

public class Book {
    private int bookId;
    private int copyId; // Novo campo para o ID da cópia
    private String title;
    private String author;
    private int totalCopies;
    private int availableCopies;
    private long issueDate; // Date in milliseconds

    public Book(int bookId, String title, String author, int totalCopies) {
        this.bookId = bookId;
        this.copyId = 1; // Inicialize o ID da cópia com 1 por padrão
        this.title = title;
        this.author = author;
        this.totalCopies = totalCopies;
        this.availableCopies = totalCopies;
        this.issueDate = -1; // Valor padrão quando não estiver emprestado
    }


    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public int getCopyId() {
        return copyId;
    }

    public void setCopyId(int copyId) {
        this.copyId = copyId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getTotalCopies() {
        return totalCopies;
    }

    public void setTotalCopies(int totalCopies) {
        this.totalCopies = totalCopies;
    }

    public int getAvailableCopies() {
        return availableCopies;
    }

    public void setAvailableCopies(int availableCopies) {
        this.availableCopies = availableCopies;
    }

    public long getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(long issueDate) {
        this.issueDate = issueDate;
    }

    public void decreaseAvailableCopies() {
        if (availableCopies > 0) {
            availableCopies--;
        }
    }

    public void increaseAvailableCopies() {
        if (availableCopies < totalCopies) {
            availableCopies++;
        }
    }

    @Override
    public String toString() {
        return "Book ID - " + bookId + " (Copy " + copyId + ")\nTitle: " + title + "\nAuthor: " + author + "\nTotal Copies: " + totalCopies + "\nAvailable Copies: " + availableCopies + "\nIssue Date: " + new Date(issueDate);
    }
}
