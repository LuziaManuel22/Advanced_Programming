package org.example;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class LibraryManagementSystem {
    private List<Book> books;
    private List<Member> members;
    private Scanner scanner;

    private LibraryManager libraryManager;
    private Member currentMember;

    public LibraryManagementSystem() {
        this.books = new ArrayList<>();
        this.members = new ArrayList<>();
        this.scanner = new Scanner(System.in);
        this.libraryManager = new LibraryManager();
        this.currentMember = null; // O membro atual será definido quando entrar como membro
    }

    public void run() {
        System.out.println(); // Isso irá imprimir uma linha em branco no console
        System.out.println(); // Isso irá imprimir uma linha em branco no console
        System.out.println("Library Portal Initialized.........");
        System.out.println("---------------------------------");
        System.out.println("1. Enter as a librarian");
        System.out.println("2. Enter as a member");
        System.out.println("3. Exit");
        System.out.println("---------------------------------");

        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (choice) {
            case 1:
                librarianMenu();
                break;
            case 2:
                memberMenu();
                break;
            case 3:
                System.out.println("Thanks for visiting!");
                System.exit(0);
                break;
            default:
                System.out.println("Invalid choice. Please select a valid option.");
                run(); // Restart the menu
                break;
        }
    }

    private void librarianMenu() {
        boolean exit = false;
        int memberId; // Declarar a variável aqui

        while (!exit) {
            System.out.println("---------------------------------");
            System.out.println(); // Isso irá imprimir uma linha em branco no console
            System.out.println("1. Register Member");
            System.out.println("2. Remove Member");
            System.out.println("3. Add Book");
            System.out.println("4. Remove Book");
            System.out.println("5. View all members along with their books and fines to be paid");
            System.out.println("6. View all books");
            System.out.println("7. Back");
            System.out.println("---------------------------------");


            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            int bookId = 0; // Declare a variável fora do switch com um valor inicial
            switch (choice) {
                case 1:
                    System.out.println("---------------------------------");
                    System.out.print("Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Age: ");
                    int age = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Phone no: ");
                    String phoneNumber = scanner.nextLine();
                    System.out.println("---------------------------------");
                    memberId = libraryManager.registerMember(name, age, phoneNumber); // Atribuir o valor aqui
                    System.out.println("Member Successfully Registered with Member ID: " + memberId);
                    System.out.println("---------------------------------");
                    break;
                case 2:
                    System.out.println("---------------------------------");
                    if (libraryManager.getMembers().isEmpty()) {
                        System.out.println("No members registered. Please register members first.");
                    } else {
                        System.out.print("Enter member ID to remove: ");
                        memberId = scanner.nextInt(); // Reutilizar a variável memberId
                        libraryManager.removeMember(memberId);
                    }
                    break;
                case 3:
                    System.out.println("---------------------------------");
                    System.out.print("Enter book title: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter book author: ");
                    String author = scanner.nextLine();
                    System.out.print("Enter total copies: ");
                    int totalCopies = scanner.nextInt();
                    libraryManager.addBook( title, author, totalCopies);
                    break;
                case 4:
                    System.out.println("---------------------------------");
                    System.out.print("Enter book ID to remove: ");
                    int removeBookId = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.println("---------------------------------");

                    boolean removed = libraryManager.removeBook(removeBookId);
                    if (removed) {
                        System.out.println("Book with ID " + removeBookId + " has been removed.");
                        System.out.println("---------------------------------");
                        scanner.nextLine(); // Consume newline
                    } else {
                        System.out.println("Book with ID " + removeBookId + " does not exist.");
                    }
                    System.out.println("---------------------------------");
                    break;
                case 5:
                    System.out.println("---------------------------------");
                    if (libraryManager.getMembers().isEmpty()) {
                        System.out.println("No members registered. Please register members first.");
                    } else {
                        List<String> membersInfo = libraryManager.viewMembersWithBooksAndFines();
                        for (String info : membersInfo) {
                            System.out.println(info);
                        }
                    }
                    System.out.println("---------------------------------");
                    break;
                case 6:
                    System.out.println("---------------------------------");
                    if (libraryManager.getBooks().isEmpty()) {
                        System.out.println("No books registered. Please register books first.");
                    } else {
                        libraryManager.viewBooks();
                    }
                    System.out.println("---------------------------------");
                    break;
                case 7:
                    run();
                    break;
                default:
                    System.out.println("Invalid choice. Please select a valid option.");
                    break;
            }
        }
    }

    private void memberMenu() {
        boolean exit = false;
        while (!exit) {

            if (currentMember == null) {
                // Se não houver um membro atualmente logado, solicite o nome e o número do membro
                System.out.println("Enter your Name: ");
                String memberName = scanner.nextLine();
                System.out.println("Enter your Phone No: ");
                String phoneNumber = scanner.nextLine();

                currentMember = libraryManager.findMemberByNameAndPhone(memberName, phoneNumber);
                if (currentMember == null) {
                    System.out.println("Member with Name: " + memberName + " and Phone No: " + phoneNumber + " doesn't exist.");
                    run();
                    break;
                } else {
                    System.out.println("Welcome " + currentMember.getName() + ". Member ID: " + currentMember.getMemberId());
                }
            }

                System.out.println("---------------------------------");
                System.out.println("1. List Available Books");
                System.out.println("2. List My Books");
                System.out.println("3. Issue Book");
                System.out.println("4. Return Book");
                System.out.println("5. Pay Fine");
                System.out.println("6. Back");
                System.out.println("---------------------------------");


                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                    case 1:
                        System.out.println("---------------------------------");
                        currentMember.listAvailableBooks(libraryManager.getAvailableBooks());
                        System.out.println("---------------------------------");
                        break;
                    case 2:
                        System.out.println("---------------------------------");
                        currentMember.listMyBooks();
                        System.out.println("---------------------------------");
                        break;
                    case 3:
                        System.out.println("---------------------------------");
                        System.out.print("Enter book ID: ");
                        int bookId = scanner.nextInt();
                        scanner.nextLine(); // Consume newline
                        System.out.print("Enter book title: ");
                        String bookTitle = scanner.nextLine();
                        System.out.println("---------------------------------");

                        Book bookToIssue = libraryManager.findBookById(bookId);

                        if (bookToIssue != null && bookToIssue.getTitle().equalsIgnoreCase(bookTitle)) {
                            System.out.println("---------------------------------");
                            currentMember.issueBook(bookToIssue);
                            System.out.println("---------------------------------");
                        } else {
                            System.out.println("Book not found or title does not match the ID.");
                        }
                        break;
                    case 4:
                        System.out.println("---------------------------------");
                        System.out.print("Enter Book ID to return: ");
                        int returnBookId = scanner.nextInt();
                        scanner.nextLine(); // Consume newline
                        System.out.println("---------------------------------");
                        Book returnBook = libraryManager.findBookById(returnBookId);
                        if (returnBook != null) {
                            currentMember.returnBook(returnBook, 4); // 4 representa o número de dias de atraso
                            System.out.println("---------------------------------");
                            scanner.nextLine(); // Consume newline
                            System.out.println("Book ID: " + returnBookId + " successfully returned. 12 Rupees has been charged for a delay of 4 days.");
                            System.out.println("---------------------------------");
                            scanner.nextLine(); // Consume newline
                        } else {
                            System.out.println("Invalid Book ID.");
                        }
                        System.out.println("---------------------------------");
                        break;
                    case 5:
                        System.out.println("---------------------------------");
                        System.out.print("Enter the amount to pay: ");
                        double amount = scanner.nextDouble();
                        scanner.nextLine(); // Consume newline
                        System.out.println("---------------------------------");
                        currentMember.payFine(amount);
                        System.out.println("---------------------------------");
                        break;
                    case 6:
                        currentMember = null; // Logout do membro
                        run(); // Retorna ao menu principal
                        exit = true; // Sai do loop do menu de membro
                        break;
                    default:
                        System.out.println("Invalid choice. Please select a valid option.");
                        break;
                }
            }
        }


    }


