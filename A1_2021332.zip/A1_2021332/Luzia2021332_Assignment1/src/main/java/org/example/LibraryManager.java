package org.example;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class LibraryManager {
    private List<Member> members;
    private List<Book> books;
    private Scanner scanner; // Adicione uma variável de instância para o Scanner

    public LibraryManager() {
        this.members = new ArrayList<>();
        this.books = new ArrayList<>();
        this.scanner = new Scanner(System.in); // Inicialize o Scanner aqui
    }

    public List<Member> getMembers() {
        return members;
    }

    public void setMembers(List<Member> members) {
        this.members = members;
    }

    public List<Book> getBooks() {
        return books;
    }

    public void setBooks(List<Book> books) {
        this.books = books;
    }

    public Member findMemberByNameAndPhone(String name, String phone) {
        for (Member member : members) {
            if (member.getName().equals(name) && member.getPhoneNumber().equals(phone)) {
                return member;
            }
        }
        return null; // Retorna null se não encontrar um membro com o nome e telefone fornecidos
    }

    public List<String> viewMembersWithBooksAndFines() {
        List<String> memberInfo = new ArrayList<>();

        for (Member member : members) {
            StringBuilder info = new StringBuilder();
            info.append("Member ID: ").append(member.getMemberId()).append("\n");
            info.append("Name: ").append(member.getName()).append("\n");
            info.append("Books Borrowed:\n");

            for (Book book : member.getBorrowedBooks()) {
                info.append("  - ").append(book.getTitle()).append("\n");
            }

            double fine = member.getPenaltyAmount(); // Corrija para getPenaltyAmount()
            if (fine > 0) {
                info.append("Fine to be paid: ").append(fine).append(" Rupees\n");
            } else {
                info.append("No fines pending\n");
            }

            memberInfo.add(info.toString());
        }

        return memberInfo;
    }


    // Métodos para registrar e remover membros
    public int registerMember(String name, int age, String phoneNumber) {
        Member member = new Member(name, age, phoneNumber);
        members.add(member);
        return member.getMemberId(); // Retorna o ID do membro recém-registrado
    }

    public void removeMember(int memberId) {
        Member memberToRemove = findMemberById(memberId);
        if (memberToRemove != null) {
            members.remove(memberToRemove);
        }
    }

    // Métodos para adicionar e remover livros
    public void addBook(String title, String author, int totalCopies) {
        int initialBookId = books.size() + 1; // ID inicial do livro
        for (int i = 0; i < totalCopies; i++) {
            int bookId = initialBookId + i; // Gere automaticamente um novo ID para a cópia do livro
            Book book = new Book(bookId, title, author, totalCopies);
            books.add(book);
        }
        System.out.println("Book Added Successfully!");
    }

    public boolean removeBook(int bookId) {
        Book bookToRemove = findBookById(bookId);
        if (bookToRemove != null) {
            books.remove(bookToRemove);
            return true; // Indica que o livro foi removido com sucesso
        }
        return false; // Indica que o livro não foi encontrado
    }


    // Métodos auxiliares para encontrar membros e livros pelo ID
    public Member findMemberById(int memberId) {
        for (Member member : members) {
            if (member.getMemberId() == memberId) {
                return member;
            }
        }
        return null; // Retorna null se o membro não for encontrado
    }

    public Book findBookById(int bookId) {
        for (Book book : books) {
            if (book.getBookId() == bookId) {
                return book;
            }
        }
        return null;
    }

    public Book findBookByTitle(String bookTitle) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(bookTitle)) {
                return book;
            }
        }
        return null;
    }


    // Método para visualizar membros
    public void viewMembers() {
        System.out.println("List of Members:");
        for (Member member : members) {
            System.out.println(member);
        }
    }

    // Método para visualizar livros
    public void viewBooks() {
        System.out.println("---------------------------------");
        for (Book book : books) {
            System.out.println("Book ID - " + book.getBookId());
            System.out.println("Name - " + book.getTitle());
            System.out.println("Author - " + book.getAuthor());
            System.out.println();
        }
            System.out.println("---------------------------------");

    }

    public List<Book> getAvailableBooks() {
        List<Book> availableBooks = new ArrayList<>();
        for (Book book : books) {
            if (book.getAvailableCopies() > 0) {
                availableBooks.add(book);
            }
        }
        return availableBooks;
    }

    // Método para calcular a multa para um livro
    public void calculateFine(Book book, int daysLate) {
        double fine = 0.0;
        if (daysLate > 0) {
            fine = daysLate * 3.0; // Assumindo que a multa é de 3 reais por dia de atraso
        }
        System.out.println("Fine for book ID " + book.getBookId() + ": " + fine);
        System.out.println("---------------------------------");
        scanner.nextLine(); // Consume newline
    }

    // Método para emitir um livro para um membro
    public void issueBook(int memberId, int bookId) {
        Member member = findMemberById(memberId);
        Book book = findBookById(bookId);

        if (member != null && book != null) {
            if (book.getAvailableCopies() > 0) {
                member.issueBook(book);
                book.decreaseAvailableCopies();
                long currentTimeMillis = System.currentTimeMillis();
                book.setIssueDate(currentTimeMillis);
                System.out.println("Book issued successfully.");
                System.out.println("---------------------------------");
                scanner.nextLine(); // Consume newline
            } else {
                System.out.println("No available copies of this book.");
                System.out.println("---------------------------------");
                scanner.nextLine(); // Consume newline
            }
        } else {
            System.out.println("Member or book not found.");
            System.out.println("---------------------------------");
            scanner.nextLine(); // Consume newline
        }
    }

    // Método para devolver um livro por um membro
    public void returnBook(int memberId, int bookId) {
        Member member = findMemberById(memberId);
        Book book = findBookById(bookId);

        if (member != null && book != null) {
            if (member.getBorrowedBooks().contains(book)) {
                long currentTimeMillis = System.currentTimeMillis();
                long issueDate = book.getIssueDate();
                int daysLate = (int) ((currentTimeMillis - issueDate) / (24 * 60 * 60 * 1000)); // Calculate days late
                member.returnBook(book, daysLate);
                book.increaseAvailableCopies();
                System.out.println("Book returned successfully.");
                System.out.println("---------------------------------");
                scanner.nextLine(); // Consume newline
            } else {
                System.out.println("You have not borrowed this book.");
                System.out.println("---------------------------------");
                scanner.nextLine(); // Consume newline
            }
        } else {
            System.out.println("Member or book not found.");
            System.out.println("---------------------------------");
            scanner.nextLine(); // Consume newline
        }
    }
}
