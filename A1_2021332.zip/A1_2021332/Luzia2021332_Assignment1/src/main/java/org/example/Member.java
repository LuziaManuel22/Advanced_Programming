package org.example;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;

public class Member {
    private static int nextMemberId = 1;
    private int memberId;
    private String name;
    private int age;
    private String phoneNumber;
    private List<Book> borrowedBooks;
    private double penaltyAmount;

    public Member(String name, int age, String phoneNumber) {
        this.memberId = nextMemberId++;
        this.name = name;
        this.age = age;
        this.phoneNumber = phoneNumber;
        this.borrowedBooks = new ArrayList<>();
        this.penaltyAmount = 0;
    }

    public int getMemberId() {
        return memberId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public List<Book> getBorrowedBooks() {
        return borrowedBooks;
    }

    public double getPenaltyAmount() {
        return penaltyAmount;
    }

    public void setPenaltyAmount(double penaltyAmount) {
        this.penaltyAmount = penaltyAmount;
    }

    public void addBorrowedBook(Book book) {
        borrowedBooks.add(book);
    }

    public void returnBook(Book book, int daysLate) {
        if (borrowedBooks.contains(book)) {
            borrowedBooks.remove(book);
            double penalty = daysLate * 3; // Assumindo que 1 dia = 1 unidade de penalidade (ajuste conforme necessário)
            penaltyAmount += penalty;
            System.out.println("Book returned successfully.");

            if (penaltyAmount > 0) {
                System.out.println("Penalty of " + penaltyAmount + " rupees has been charged for a delay of " + daysLate + " days.");
            }
        } else {
            System.out.println("You have not borrowed this book.");
        }
    }



    public void listAvailableBooks(List<Book> availableBooks) {
        if (availableBooks.isEmpty()) {
            System.out.println("No available books.");
        } else {
            System.out.println("Available Books:");
            Date currentDate = new Date(); // Obtém a data e hora atual
            for (Book book : availableBooks) {
                System.out.println("Title: " + book.getTitle());
                System.out.println("Author: " + book.getAuthor());
                System.out.println("Total Copies: " + book.getTotalCopies());
                System.out.println("Available Copies: " + book.getAvailableCopies());
                System.out.println("Issue Date: " + currentDate); // Exibe a data e hora atual
                System.out.println();
            }
        }
    }

    public void listMyBooks() {
        if (borrowedBooks.isEmpty()) {
            System.out.println("You have not borrowed any books.");
        } else {
            System.out.println("Your Borrowed Books:");
            for (Book book : borrowedBooks) {
                System.out.println("Book ID: " + book.getBookId());
                System.out.println("Title: " + book.getTitle());
                System.out.println("Author: " + book.getAuthor());
                System.out.println("Total Copies: " + book.getTotalCopies());
                System.out.println("Available Copies: " + book.getAvailableCopies());
                System.out.println();
            }
        }
    }


    public void payFine(double amount) {
        if (amount <= penaltyAmount) {
            penaltyAmount -= amount;
            System.out.println("Penalty paid successfully. Remaining penalty amount: " + penaltyAmount + " rupees.");
        } else {
            System.out.println("Amount exceeds penalty amount. Penalty amount: " + penaltyAmount + " rupees.");
        }
    }

    public void issueBook(Book book) {
        if (book.getAvailableCopies() > 0) {
            borrowedBooks.add(book);
            book.decreaseAvailableCopies();
            long currentTimeMillis = System.currentTimeMillis();
            book.setIssueDate(currentTimeMillis);
            System.out.println("Book issued successfully.");
        } else {
            System.out.println("No available copies of this book.");
        }
    }



    @Override
    public String toString() {
        return "Member ID: " + memberId +
                "\nName: " + name +
                "\nAge: " + age +
                "\nPhone no: " + phoneNumber +
                "\nPenalty amount: " + penaltyAmount +
                "\nBorrowed books: " + borrowedBooks.size();
    }
}
